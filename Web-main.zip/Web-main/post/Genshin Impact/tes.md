---
title: 'TesTes'
subtitle: 'Tes'
banner: ""
lang: "en-US"
category: "Genshin Impact"
type_label: "YuukiPS"
tag_label: 1
tag_icon: "https://gitlab.com/yukiz/grasscutter-data/-/raw/main/data/hk4e/announcement/image/alert/warning.png"
tag_start_time: "2000-01-02 15:04:05"
tag_end_time: "2030-01-02 15:04:05"
login_alert: 1
alert: 0
remind: 1
remind_ver: 1
extra_remind: 1
has_content: true
type: 1
start_time: "2022-07-13 07:00:00"
end_time: "2030-08-24 06:00:00"
date: "2022-08-22"
---
# Melon :)