# YuukiGame-Web
This is for yuuki server for web purposes.

## Getting Started

First, run development server:

```bash
npm update
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Announcement Post

TODO: